In order to work on this project, at a minimum you will need:
- [.NET Core 2/2.1](https://www.microsoft.com/net/download)
- [Visual Studio Code](https://code.visualstudio.com/) with the [C#](https://marketplace.visualstudio.com/items?itemName=ms-vscode.csharp) extension.

If you are using a Windows machine, and are used to using Visual Studio with other extensions, e.g. Resharper, the please feel free to use that.

