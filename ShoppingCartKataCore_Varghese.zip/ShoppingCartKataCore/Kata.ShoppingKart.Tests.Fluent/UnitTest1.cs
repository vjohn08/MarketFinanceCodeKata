using FluentAssertions;
using Kata.ShoppingCart;
using System;
using Xunit;

namespace Kata.ShoppingKart.Tests.Fluent
{
    public class CheckoutTests
    {
        private readonly ICheckout _sut;

        public CheckoutTests()
        {
            var repo = new PriceRepo();

            _sut = new Checkout(repo);
        }

        [Fact]
        public void When_One_Item()
        {
            var result = _sut.GetTotal("A");

            Assert.Equal(50, result);
        }

        [Fact]
        public void When_Two_Items()
        {
            var result = _sut.GetTotal("AB");

            Assert.Equal(80, result);
        }

        [Fact]
        public void When_Item_Repeats()
        {
            var result = _sut.GetTotal("AA");

            Assert.Equal(100, result);
        }

        [Fact]
        public void When_Item_Repeats_And_Has_Another_Item()
        {
            var result = _sut.GetTotal("ABA");

            Assert.Equal(130, result);
        }

        [Fact]
        public void When_Item_Count_Equals_Offer()
        {
            var result = _sut.GetTotal("AAA");

            Assert.Equal(130, result);
        }
    }
}
