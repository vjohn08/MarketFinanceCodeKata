﻿namespace Kata.ShoppingCart
{
    public interface ICheckout
    {
        double GetTotal(string items);
    }
}