﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Kata.ShoppingCart
{
    public interface IPriceCalculationStrategy
    {
    }
    public class Checkout : ICheckout
    {
        private readonly IPriceRepository _repo;

        public Checkout(IPriceRepository repo)
        {
            _repo = repo;
        }

        public double GetTotal(string items)
        {
            var itemList = Parse(items);

            var itemsAndCount = GetCount(itemList);

            var priceData = _repo.GetPriceData();

            var offerData = _repo.GetOffers();

            double totalPrice = 0;
            foreach (var item in itemsAndCount.Keys)
            {
                var hasOffer = offerData.ContainsKey(item);
                if (hasOffer)
                {
                    var offerCount = offerData[item].ItemCount;
                    var itemCount = itemsAndCount[item];

                    var numItemsInOffer = itemCount / offerCount;
                    var numItemsNotInOffer = itemCount - (offerCount * numItemsInOffer);
                    var offerPrice = numItemsInOffer * offerData[item].Price;
                    var extraPrice = numItemsNotInOffer * priceData[item];

                    totalPrice += (offerPrice + extraPrice);
                }
                else
                {
                    var price = itemsAndCount[item] * priceData[item];

                    totalPrice += price;
                }
            }

            return totalPrice;
        }

        private double GetPriceForItem(int count, double priceForItem)
        {
            return count * priceForItem;
        }

        private List<string> Parse(string items)
        {
            return items.Aggregate(new List<string>(), (acc, next) =>
            {
                acc.Add(next.ToString());

                return acc;
            });
        }

        private Dictionary<string, int> GetCount(List<string> itemList)
        {
            var result = itemList.Aggregate(new Dictionary<string, int>(), (acc, next) =>
             {
                 if (acc.ContainsKey(next))
                 {
                     acc[next]++;
                 }
                 else
                 {
                     acc.Add(next, 1);
                 }
                 return acc;
             });

            return result;
        }
    }

    public class Offer
    {
        public int ItemCount { get; }
        public double Price { get; }

        public Offer(int itemCount, double price)
        {
            ItemCount = itemCount;
            Price = price;
        }
    }

    public interface IPriceRepository
    {
        Dictionary<string, double> GetPriceData();
        Dictionary<string, Offer> GetOffers();
    }

    public class PriceRepo : IPriceRepository
    {
        public Dictionary<string, Offer> GetOffers()
        {
            return PricingData.GetOffers();
        }

        public Dictionary<string, double> GetPriceData()
        {
            return PricingData.GetPriceData();
        }
    }

    public static class PricingData
    {
        public static Dictionary<string, double> GetPriceData()
        {
            return new Dictionary<string, double>
            {
                { "A", 50},
                { "B", 30},
                { "C", 20},
                { "D", 15}
            };
        }

        public static Dictionary<string, Offer> GetOffers()
        {
            var offerForA = new Offer(3, 130);
            var offerForB = new Offer(2, 45);

            return new Dictionary<string, Offer>
            {
                { "A", offerForA},
                { "B", offerForB},
            };
        }
    }


}