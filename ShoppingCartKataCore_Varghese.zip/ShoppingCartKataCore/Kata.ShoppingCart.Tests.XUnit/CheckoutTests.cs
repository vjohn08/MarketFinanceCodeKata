using System;
using Xunit;

namespace Kata.ShoppingCart.Tests.XUnit
{
    public class CheckoutTests
    {
        private readonly ICheckout _sut;
        
        public CheckoutTests()
        {
            var repo = new PriceRepo();

            _sut = new Checkout(repo);
        }

        [Fact]
        public void When_One_Item()
        {                   
            var result = _sut.GetTotal("A");

            Assert.Equal(50, result);
        }

        [Fact]
        public void When_Two_Items()
        {
            var result = _sut.GetTotal("AB");

            Assert.Equal(80, result);
        }


    }
}